#include "date.h"

char *getCompileDate()
{
    char *strclone() ;

    return(strclone(DATE));
}
