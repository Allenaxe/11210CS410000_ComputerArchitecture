void check_rr_graph (enum e_route_type route_type, int num_switch);
void check_node (int inode, enum e_route_type route_type); 
