void routing_stats (boolean full_stats, enum e_route_type route_type, 
         int num_switch, int num_segment, float R_minW_nmos, float 
         R_minW_pmos);
void print_wirelen_prob_dist (void); 
void print_lambda (void);
