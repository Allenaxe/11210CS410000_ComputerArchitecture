void check_route (enum e_route_type route_type, int num_switch);
