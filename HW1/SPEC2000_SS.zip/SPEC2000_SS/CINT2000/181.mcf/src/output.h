/**************************************************************************
FILE: output.h

AUTHOR: Andreas Loebel

    Konrad-Zuse-Zentrum fuer Informationstechnik Berlin (ZIB)
    Takustr. 7
    14195 Berlin-Dahlem

Copyright (c) 1998,1999   ZIB Berlin   All Rights Reserved
**************************************************************************/
/*  LAST EDIT: Mon Feb 22 17:41:46 1999 by Andreas Loebel (opt0)  */


#ifndef _OUTPUT_H
#define _OUTPUT_H


#include "mcfutil.h"


extern long write_circulations _PROTO_(( char *, network_t * ));


#endif
